let floorplanIMG;
let floorplan

let counterIMG;
let counter;

let tableIMG;
let table1;
let table2;
let table3;
let table4;

let chairIMG;
let chair1;
let chair2;
let chair3;
let chair4;
let chair5;
let chair6;
let chair7;
let chair8;

let meatIMG;
let meat;

let menuStandIMG;
let menuStand;

let menuList; //replace with menu zoom in png
let menuListIMG;
let menuListStay = false; //to keep the menu in frame

let waiterSound; //repplace with waiter sound saying welcome

let menuList1;

function preload() {
  floorplanIMG = loadImage("assets/floorplan.PNG");
  counterIMG = loadImage("assets/order-counter.PNG");
  tableIMG = loadImage("assets/table.PNG");
  chairIMG = loadImage("assets/chair.PNG");
  meatIMG = loadImage("assets/meat.PNG");
  menuStandIMG = loadImage("assets/menu-stand.PNG")
  menuListIMG = loadImage("assets/menu-list.PNG")

  waiterSound = loadSound("assets/honk1.mp3")

}

function setup() {
  let cnv = createCanvas(windowWidth, windowHeight);
  cnv.parent("canvas-parent")

  floorplan = new FloorPlan(width / 2, height / 2, floorplanIMG);

  counter = new Counter(775, 80, counterIMG);

  table1 = new Table(300, 225, tableIMG);
  table2 = new Table(300, 625, tableIMG);
  table3 = new Table(1400, 225, tableIMG);
  table4 = new Table(1400, 625, tableIMG);

  chair1 = new Chair(200, 225, chairIMG);
  chair2 = new Chair(625, 400, chairIMG);
  chair3 = new Chair(200, 800, chairIMG);
  chair4 = new Chair(630, 600, chairIMG);
  chair5 = new Chair(1300, 400, chairIMG);
  chair6 = new Chair(1750, 225, chairIMG);
  chair7 = new Chair(1300, 600, chairIMG);
  chair8 = new Chair(1750, 800, chairIMG);

  menuStand = new MenuStand(1100, 250, menuStandIMG);

  menuList = new MenuList(1350, 100, menuListIMG);

  menuList1 = new MenuList(1350, 300, menuListIMG);
}

function draw() {
  clear(); // delete background
  background(200, 100, 100);

  floorplan.display();

  counter.display();

  table1.display();
  table2.display();
  table3.display();
  table4.display();

  chair1.display();
  chair2.display();
  chair3.display();
  chair4.display();
  chair5.display();
  chair6.display();
  chair7.display();
  chair8.display();

  menuStand.display();

  if (mouseIsPressed) {
    if (mouseX > 970 && mouseX < 1110 &&
      mouseY > 97 && mouseY < 255) {
      push();
      waiterSound.play();
      pop();
    }
  }

  //get rid of menu list when click on back
  if (mouseIsPressed) {
    if (mouseX > 1380 && mouseX < 1462 &&
      mouseY > 435 && mouseY < 365) {
      push();
      //menuListStay = false;
      menuList1.display();
      console.log("false")
      pop();
    }
  }

  // if true then keep menu in frame
  if (menuListStay) {
    push();
    menuList.display();
    pop();
  }
  //where you call menu to be true to stay 
  if (mouseIsPressed) {
    if (mouseX > 1120 && mouseX < 1260 &&
      mouseY > 280 && mouseY < 366) {
      push();
      menuListStay = true;
      pop();
    } 
    
    // else {
    //   menuListStay = false;
    // }
  }

}

class FloorPlan {
  constructor(floorplanX, floorplanY, floorplanIMG) {
    this.x = floorplanX;
    this.y = floorplanY;
    this.photo = floorplanIMG;
  }

  display() {
    push();
    let imgW = this.photo.width;
    let imgH = this.photo.height;

    image(this.photo, 0, 0, imgW * 1.11, imgH);

    pop();
  }
}

class Counter {
  constructor(counterX, counterY, counterIMG, waiterSound) {
    this.x = counterX;
    this.y = counterY;
    this.photo = counterIMG;
    this.sound = waiterSound;
  }

  display() {
    push();
    translate(this.x, this.y);
    let imgW = this.photo.width;
    let imgH = this.photo.height;

    // fill('red')
    // circle(0,0,30);

    //check if clicking in the rect
    if (this.isDragged == true) {
      fill("red")
    } else {
      fill("white")
    }
    rect(195, 20, 140, 160);
    image(this.photo, 0, 0, imgW, imgH);
    pop();
  }

  // isClicked(mx,my){
  //   let d=dist(mx,my,this.x,this.y);
  //   return d<
  // }

  checkIfPressed() {
    if (mouseX > this.x + 195 &&
      mouseX < this.x + 335 &&
      mouseY > this.y + 20 &&
      mouseY < this.y + 180
    ) {
      this.isDragged = true;
    }
  }

  playSound() {
    if (this.sound && !this.sound.isPlaying()) {
      this.sound.play();
    }
  }
}

class Table {
  constructor(tableX, tableY, tableIMG) {
    this.x = tableX;
    this.y = tableY;
    this.photo = tableIMG;
  }

  display() {
    push();
    translate(this.x, this.y);
    let imgW = this.photo.width;
    let imgH = this.photo.height;

    image(this.photo, 0, 0, imgW * 0.8, imgH * 0.8);
    pop();
  }
}


class Chair {
  constructor(chairX, chairY, chairIMG) {
    this.x = chairX;
    this.y = chairY;
    this.photo = chairIMG;
  }

  display() {
    push();
    translate(this.x, this.y);
    let imgW = this.photo.width;
    let imgH = this.photo.height;

    image(this.photo, 0, 0, imgW, imgH)
    pop();
  }
}

class MenuStand {
  constructor(menustandX, menustandY, menuStandIMG) {
    this.x = menustandX;
    this.y = menustandY;
    this.photo = menuStandIMG
  }

  display() {
    push();
    translate(this.x, this.y);
    let imgW = this.photo.width;
    let imgH = this.photo.height;

    //  fill('red')
    // circle(0,0,30);

    //check if clicking in the rect
    if (this.isDragged == true) {
      fill("red")
    } else {
      fill("white")
    }
    rect(22, 25, 140, 90);

    image(this.photo, 0, 0, imgW * 0.8, imgH * 1)
    pop();
  }

  //   checkIfPressed() { //deal later
  //         if (mouseX > this.x +22  && //+xposition
  //             mouseX < this.x + 162  && //+xposition+width
  //             mouseY > this.y +25 && //+yposition
  //             mouseY < this.y + 115 //+yposition+height
  //         ) {
  //             this.isDragged = true;
  //         }
  // }
}

class MenuList {
  constructor(menuListX, menuListY, menuListIMG) {
    this.x = menuListX;
    this.y = menuListY;
    this.photo = menuListIMG;
  }

  display() {
    push();
    translate(this.x, this.y);
    let imgW = this.photo.width;
    let imgH = this.photo.height;

    fill('red')
    circle(0,0,10);

    // if (this.isDragged == true) {
    //   fill("red")
    // } else {
    //   fill("white")
    // }

    // fill(255,100)
    // rect(195, 20, 140, 160);

    image(this.photo, 0, 0, imgW / 4, imgH / 4);
    pop();
  }
}

function mousePressed() {
  console.log("pressed")
  console.log(mouseX, mouseY);
  counter.checkIfPressed();

}

function mouseReleased() {
  console.log("released")
  counter.isDragged = false; //for waiter rect
  //menuStand.isDragged=false; 
}


