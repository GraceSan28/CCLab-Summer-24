let restaurant;
let restaurantIMG;

let tree;
let treeIMG;

let roadIMG;
let road;
let road2;
let road3;
let road4;
let road5;

let roads = [];
let numRoad = 1;

let fruitIMG;
let fruit1; 
let fruit2; 
let fruit3;

let bushIMG;
let bush1;
let bush2;
let bush3;
let bush4;

let flowerIMG;
let flower1;
let flower2;
let flower3;
let flower4;
let flower5;
let flower6;
let flower7;
let flower8;

let honk1;

function preload() {
  roadIMG = loadImage("assets/cobblestone.PNG");
  restaurantIMG = loadImage("assets/restaurant-exterior.PNG");
  treeIMG = loadImage("assets/tree.PNG");
  fruitIMG = loadImage("assets/fruit.PNG");
  bushIMG=loadImage("assets/bush.PNG");
  flowerIMG=loadImage("assets/flower.PNG");

  flowerSound = loadSound("assets/honk1.mp3");
}



function setup() {
  let cnv = createCanvas(windowWidth, windowHeight);
  cnv.parent("canvas-parent");

  for (let i = 0; i < numRoad; i++) {
    let oneRoad = new Road(width / 4, height / 2, roadIMG);
    roads.push(oneRoad);
  }

  road2 = new Road(width / 4, height / 2 + 100, roadIMG);
  road3 = new Road(500, 685, roadIMG);
  road4 = new Road(550, height / 2 + 300, roadIMG);
  road5 = new Road(600, height / 2 + 400, roadIMG);

  restaurant = new Restaurant(width / 6, -20, restaurantIMG);

  tree = new Tree(1150, 50, treeIMG);

  fruit1 = new Fruit(1200, 175, fruitIMG);
  fruit2 = new Fruit(1250, 250, fruitIMG);
  fruit3 = new Fruit(1300, 175, fruitIMG);

  bush1 = new Bush(40,500,bushIMG);
  bush2 = new Bush(40,700,bushIMG);
  bush3 = new Bush(750,500,bushIMG);
  bush4 = new Bush(900,700,bushIMG);

  flower1= new Flower(155,600,flowerIMG);
  flower2= new Flower(270,590,flowerIMG);
  flower3= new Flower(170,780,flowerIMG);
  flower4= new Flower(260,800,flowerIMG);
  flower5=new Flower(875,590,flowerIMG);
  flower6=new Flower(980,600,flowerIMG);
  flower7=new Flower(1025,800,flowerIMG);
  flower8=new Flower(1125,775,flowerIMG);
}

function draw() {
  clear(); // delete background
  for (let i = 0; i < roads.length; i++) {
    roads[i].display();
  }
  road2.display();
  road3.display();
  road4.display();
  road5.display();

  restaurant.display();

  tree.display();
  tree.update();

  fruit1.update();
  fruit1.display();
  fruit2.update();
  fruit2.display();
  fruit3.update();
  fruit3.display();

  bush1.display();
  bush2.display();
  bush3.display();
  bush4.display();

  flower1.update();
  flower1.display();

  flower2.update();
  flower2.display();

  flower3.update();
  flower3.display();
  
  flower4.update();
  flower4.display();
  
  flower5.update();
  flower5.display();
  
  flower6.update();
  flower6.display();
  
  flower7.update();
  flower7.display();
  
  flower8.update();
  flower8.display();
}

class Road {
  constructor(roadX, roadY, roadIMG) {
    this.x = roadX;
    this.y = roadY;
    this.photo = roadIMG;
  }

  display() {
    push();
    translate(this.x, this.y);
    let imgW = this.x;
    let imgH = this.y;
    scale(0.07);
    image(this.photo, -imgW / 2, -imgH + 430);
    pop();
  }
}

class Restaurant {
  constructor(restaurantX, restaurantY, restaurantIMG) {
    this.x = restaurantX;
    this.y = restaurantY;
    this.photo = restaurantIMG;
  }

  display() {
    push();
    translate(this.x, this.y);
    let imgW = this.x;
    let imgH = this.y;
    scale(0.7);
    image(this.photo, -imgW / 2, -imgH + 15);
    pop();
  }
}

class Tree {
  constructor(treeX, treeY, treeIMG) {
    this.x = treeX;
    this.y = treeY;
    this.photo = treeIMG;
  }

  update() {
    // this.y++
  }

  display() {
    push();
    translate(this.x, this.y);
    let imgW = this.photo.width;
    let imgH = this.photo.height;
    scale(0.9);
    image(this.photo, -50, 0, imgW, imgH);
    // fill("red");
    // circle(0, 0, 10);
    pop();
  }
}

class Fruit {
  constructor(fruitX, fruitY, fruitIMG) {
    this.x = fruitX;
    this.y = fruitY;
    this.photo = fruitIMG;
    this.size = 0.05 * fruitIMG.width;
    this.isFalling = false;
    this.fallSpeed = 5;
  }

  display() {
    push();
    translate(this.x, this.y);
    let imgW = this.photo.width;
    let imgH = this.photo.height;
    scale(0.05);
    image(this.photo, -imgW / 2, -imgH / 2, imgW, imgH);
    pop();
  }

  update() {
    if (this.isFalling) {
      this.y += this.fallSpeed;
      if (this.y >= 400) {
        this.y = 400; //yLoc of where it stops 
        this.isFalling = false;
      }
    }
  }

  isClicked(mx, my) {
    let d = dist(mx, my, this.x, this.y);
    return d < this.size / 2; //click detection
  }
}

class Bush{
  constructor(bushX,bushY,bushIMG){
    this.x=bushX;
    this.y=bushY;
    this.photo=bushIMG;
  }
  
  display(){
    push();
    translate(this.x,this.y);
    let imgW=this.photo.width;
    let imgH=this.photo.height;
    scale(1.2)
    image(this.photo,0,0,imgW,imgH);
    pop();
  }
}

class Flower{
  constructor(flowerX,flowerY,flowerIMG){
    this.x=flowerX;
    this.y=flowerY;
    this.photo=flowerIMG;
    this.sound = flowerSound;
    this.angle = 30;
    this.rotateSpeed=0.5;
  }
  update(){
    this.flowerTilt();

    if(this.angle>=45){
      this.rotateSpeed-=0.5
    }

    if(this.angle<=25){
      this.rotateSpeed+=0.5
    }
  }

  flowerTilt(){
    this.angle+=this.rotateSpeed
  }
  
  display(){
    push();
    translate(this.x,this.y);
    let imgW=this.photo.width;
    let imgH=this.photo.height;

    rotate(radians(this.angle));
    fill(255,0);
    noStroke();
    circle(0,0,50) //check if within dist of click 
    scale(0.5);
   
    image(this.photo,-55,-50,imgW/10,imgH/10) 
    // fill(255);
    // circle(0,0,5);
    pop();
  }

  isClicked(mx, my) {
    let d = dist(mx, my, this.x, this.y);
    return d < 25; // because circle dia is 50
  }

  playSound() {
    //! is so the sounds don't overlap and only 1 sound plays
    if (this.sound && !this.sound.isPlaying()) {
      this.sound.play();
    }
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}

function mousePressed() {
  console.log(mouseX,mouseY);
  
  if (fruit1.isClicked(mouseX, mouseY)) {
    fruit1.isFalling = true;
  }
  if (fruit2.isClicked(mouseX, mouseY)) {
    fruit2.isFalling = true;
  }
  if (fruit3.isClicked(mouseX, mouseY)) {
    fruit3.isFalling = true;
  }

  if(flower1.isClicked(mouseX, mouseY)) {
    console.log("wefonew")
    flower1.playSound();
  }
  if(flower2.isClicked(mouseX, mouseY)) {
    flower2.playSound();
  } 
  if(flower3.isClicked(mouseX,mouseY)){
    flower3.playSound();
  }
  if(flower4.isClicked(mouseX, mouseY)) {
    console.log("wefonew")
    flower4.playSound();
  }
  if(flower5.isClicked(mouseX, mouseY)) {
    flower5.playSound();
  } 
  if(flower6.isClicked(mouseX,mouseY)){
    flower6.playSound();
  }
  if(flower7.isClicked(mouseX,mouseY)){
    flower7.playSound();
  }
  if(flower8.isClicked(mouseX,mouseY)){
    flower8.playSound();
  }
}

